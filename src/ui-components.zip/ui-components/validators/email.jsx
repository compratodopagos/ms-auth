export const validateEmail = (email) => {
  if (!email) return 'El correo es obligatorio';

  // Quitar espacios al inicio/fin
  const trimmed = email.trim();

  // Expresión regular robusta pero práctica
  const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  if (!regex.test(trimmed)) {
    return 'Formato de correo inválido';
  }

  // Reglas adicionales
  const [localPart, domain] = trimmed.split('@');

  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return 'El nombre de usuario no puede empezar ni terminar con punto';
  }

  if (domain.startsWith('-') || domain.endsWith('-')) {
    return 'El dominio no puede empezar ni terminar con guion';
  }

  if (!domain.includes('.')) {
    return 'El dominio debe contener al menos un punto (ej: ejemplo.com)';
  }

  return true; // válido
};