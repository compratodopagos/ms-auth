export const validatePassword = (password) => {
    if (!password) return 'La contraseña es obligatoria';

    const trimmed = password.trim();

    if (trimmed.length < 12) {
        return 'La contraseña debe tener al menos 12 caracteres';
    }

    if (!/[A-Z]/.test(trimmed)) {
        return 'Debe incluir al menos una letra mayúscula';
    }

    if (!/[a-z]/.test(trimmed)) {
        return 'Debe incluir al menos una letra minúscula';
    }

    if (!/[0-9]/.test(trimmed)) {
        return 'Debe incluir al menos un número';
    }

    if (!/[!@#$%^&*(),.?":{}|<>_\-+=/\\[\]`~]/.test(trimmed)) {
        return 'Debe incluir al menos un carácter especial';
    }

    if (/\s/.test(trimmed)) {
        return 'No se permiten espacios en la contraseña';
    }

    // Lista negra básica (se puede ampliar o usar una API de "haveibeenpwned")
    const commonPasswords = [
        '123456', 'password', 'qwerty', '111111', '123123',
        'abc123', 'iloveyou', 'admin', 'welcome'
    ];
    if (commonPasswords.includes(trimmed.toLowerCase())) {
        return 'La contraseña es demasiado común, usa una más segura';
    }

    return true; // ✅ válida
};