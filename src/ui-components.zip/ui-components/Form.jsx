import React, { useState } from 'react';
import { Input } from './Input';

export const FormBuilder = ({ schema, onSubmit }) => {
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    
    if (schema[name]?.validation) {
      const result = schema[name].validation(value);
      setErrors((prev) => ({
        ...prev,
        [name]: result === true ? '' : result
      }));
    }

    if (touched[name] && schema[name]?.validation) {
      const result = schema[name].validation(value);
      setErrors((prev) => ({
        ...prev,
        [name]: result === true ? '' : result
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let isValid = true;
    let newErrors = {};

    for (const field in schema) {
      if (schema[field].required && !values[field]) {
        newErrors[field] = 'Campo requerido';
        isValid = false;
      } else if (schema[field].validation) {
        const result = schema[field].validation(values[field] || '');
        if (result !== true) {
          newErrors[field] = result;
          isValid = false;
        }
      }
    }

    setErrors(newErrors);

    if (isValid) {
      onSubmit(values);
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));

    if (schema[name]?.validation) {
      const result = schema[name].validation(value);
      setErrors((prev) => ({
        ...prev,
        [name]: result === true ? '' : result
      }));
    } else if (schema[name]?.required && !value) {
      setErrors((prev) => ({
        ...prev,
        [name]: 'Campo requerido'
      }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {Object.keys(schema).map((key) => {
        const field = schema[key];
        return (
          <Input
            key={key}
            name={key}
            value={values[key] || ''}
            onChange={handleChange}
            onBlur={handleBlur}
            errorMessage={errors[key]}
            {...field}
          />
        );
      })}

      <button type="submit" className="px-4 py-2 rounded bg-blue-600 text-white">
        Enviar
      </button>
    </form>
  );
};